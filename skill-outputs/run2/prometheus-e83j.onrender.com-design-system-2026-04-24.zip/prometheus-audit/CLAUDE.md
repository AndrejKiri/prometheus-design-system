# Design System Project

## Target Application
- URL: https://prometheus-e83j.onrender.com
- Source repo: https://github.com/prometheus/prometheus (user-confirmed; used by Claude Code in Phase 1-Source)
- Auth: None (public demo)

## Scope
- Tier: TBD (set after Phase 0 route discovery)
- Pages audited: TBD
- Themes: light + dark (Prometheus UI supports both)

## Progress
- [ ] Phase 0: Scope assessment
- [ ] Phase 1: Visual audit (tool: claude-cowork)
- [ ] Phase 1-Source: Source audit (tool: claude-code, optional)
- [ ] Phase 2: Token extraction
- [ ] Phase 3: Component extraction
- [ ] Phase 4: Documentation site
- [ ] Phase 5: Figma plugin
- [ ] Phase 6: Deploy + QA

## Handoff Files
- audit-results.json   — Phase 1 output (this session)
- screenshots/         — one JPEG per page × theme (may be placeholders if sandbox blocks export)
- observations/        — raw per-page DOM/CSS notes captured during live inspection
- source-audit.json    — Phase 1-Source output (optional, Claude Code)
- tokens.json          — Phase 2 output (Claude Code)
- components.json      — Phase 3 output (Claude Code)
